/**
 * AI Reasoning Service
 *
 * Thin wrapper around a local Ollama instance (preferred, no API key) or a
 * generic cloud LLM endpoint, used to:
 *   - summarize/explain findings for the dashboard,
 *   - evaluate whether a retest response indicates a resolved vulnerability,
 *   - suggest a remediation patch description for a finding.
 *
 * If no LLM is reachable, every method falls back to a deterministic
 * heuristic so the rest of the platform (retest verification in particular)
 * keeps working offline / in CI without silently hanging or crashing.
 */
import axios from 'axios';
import { Finding } from '../types';

const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL ?? 'http://localhost:11434';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL ?? 'llama3';
const AI_API_URL = process.env.AI_API_URL ?? '';
const AI_API_KEY = process.env.AI_API_KEY ?? '';
const AI_TIMEOUT_MS = 6000;

export interface RetestEvaluation {
  isResolved: boolean;
  explanation: string;
}

export interface FixSuggestion {
  summary: string;
  patch: string;
}

/**
 * Compares the original vulnerable response against a new response and
 * decides whether the finding is resolved. Tries an LLM first; falls back
 * to deterministic status-code/body heuristics so retests never hang.
 */
export async function evaluateRetest(finding: Finding, newHttpResponse: string): Promise<RetestEvaluation> {
  const heuristic = heuristicEvaluate(finding, newHttpResponse);

  const prompt = buildEvaluationPrompt(finding, newHttpResponse);
  const llmText = await tryLlm(prompt);
  if (!llmText) {
    return heuristic;
  }

  // Prefer the LLM's natural-language explanation but trust the heuristic's
  // boolean verdict unless the model clearly disagrees with an explicit verdict line.
  const verdictMatch = llmText.match(/VERDICT:\s*(RESOLVED|VULNERABLE)/i);
  const isResolved = verdictMatch ? verdictMatch[1].toUpperCase() === 'RESOLVED' : heuristic.isResolved;

  return {
    isResolved,
    explanation: llmText.replace(/VERDICT:\s*(RESOLVED|VULNERABLE)/i, '').trim() || heuristic.explanation,
  };
}

export async function generateFix(finding: Finding): Promise<FixSuggestion> {
  const fallback = heuristicFix(finding);
  const prompt = buildFixPrompt(finding);
  const llmText = await tryLlm(prompt);
  if (!llmText) return fallback;
  return { summary: llmText.trim(), patch: fallback.patch };
}

// ---------------------------------------------------------------------------
// LLM transport
// ---------------------------------------------------------------------------

async function tryLlm(prompt: string): Promise<string | null> {
  const fromOllama = await tryOllama(prompt);
  if (fromOllama) return fromOllama;
  return tryCloudApi(prompt);
}

async function tryOllama(prompt: string): Promise<string | null> {
  try {
    const res = await axios.post(
      `${OLLAMA_BASE_URL}/api/generate`,
      { model: OLLAMA_MODEL, prompt, stream: false },
      { timeout: AI_TIMEOUT_MS }
    );
    const text = res.data?.response;
    return typeof text === 'string' && text.length > 0 ? text : null;
  } catch {
    return null; // Ollama not running locally — fall through silently.
  }
}

async function tryCloudApi(prompt: string): Promise<string | null> {
  if (!AI_API_URL || !AI_API_KEY) return null;
  try {
    const res = await axios.post(
      AI_API_URL,
      { prompt },
      { headers: { Authorization: `Bearer ${AI_API_KEY}` }, timeout: AI_TIMEOUT_MS }
    );
    const text = res.data?.text ?? res.data?.response ?? res.data?.output;
    return typeof text === 'string' && text.length > 0 ? text : null;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Prompt construction
// ---------------------------------------------------------------------------

function buildEvaluationPrompt(finding: Finding, newHttpResponse: string): string {
  return [
    'You are a security verification assistant. Compare the original vulnerable HTTP response',
    'against a new HTTP response captured after a fix was deployed, for the same request.',
    'Decide if the vulnerability is RESOLVED or still VULNERABLE.',
    'Respond with a line "VERDICT: RESOLVED" or "VERDICT: VULNERABLE" followed by a one or two sentence explanation.',
    '',
    `Finding: ${finding.title} (${finding.category}, ${finding.severity})`,
    `Endpoint: ${finding.method} ${finding.endpoint}`,
    `Original proof of exploitability: ${finding.proof}`,
    '--- Original vulnerable response ---',
    truncate(finding.httpResponse, 1500),
    '--- New response after fix ---',
    truncate(newHttpResponse, 1500),
  ].join('\n');
}

function buildFixPrompt(finding: Finding): string {
  return [
    'You are a secure-coding assistant. Given this security finding, describe a concise, concrete remediation',
    'in 2-4 sentences, referencing industry-standard practices (parameterized queries, server-side authorization',
    'checks, context-aware output encoding, security headers) as appropriate.',
    '',
    `Finding: ${finding.title} (${finding.category}, ${finding.severity})`,
    `Endpoint: ${finding.method} ${finding.endpoint}`,
    `Description: ${finding.description}`,
  ].join('\n');
}

// ---------------------------------------------------------------------------
// Deterministic fallbacks (used when no LLM is reachable)
// ---------------------------------------------------------------------------

function heuristicEvaluate(finding: Finding, newHttpResponse: string): RetestEvaluation {
  const statusMatch = newHttpResponse.match(/HTTP\/1\.1\s+(\d{3})/);
  const newStatus = statusMatch ? Number(statusMatch[1]) : null;

  if (finding.category === 'Broken Object Level Authorization' || finding.category.includes('IDOR')) {
    const blocked = newStatus === 401 || newStatus === 403 || newStatus === 404;
    return {
      isResolved: blocked,
      explanation: blocked
        ? `The endpoint now returns HTTP ${newStatus} for the cross-tenant request, indicating the authorization check is enforced.`
        : `The endpoint still returns HTTP ${newStatus ?? 'an unexpected status'} with data for the cross-tenant request; the authorization bypass appears unresolved.`,
    };
  }

  if (finding.category === 'Injection') {
    const stillReflects = newHttpResponse.includes("'") || /error.*sql/i.test(newHttpResponse);
    return {
      isResolved: !stillReflects,
      explanation: stillReflects
        ? 'The response still appears to reflect unsanitized input or a database error, suggesting the injection path remains open.'
        : 'The response no longer reflects the injection payload or a database error, consistent with parameterized queries being applied.',
    };
  }

  // Generic default: a 2xx-to-4xx status change, or the absence of the
  // original proof pattern, is treated as resolved.
  const resolved = newStatus !== null && newStatus >= 400 && newStatus < 500;
  return {
    isResolved: resolved,
    explanation: resolved
      ? `The new response returned HTTP ${newStatus}, consistent with the issue being mitigated.`
      : 'The new response does not show evidence the issue was mitigated; manual review is recommended.',
  };
}

function heuristicFix(finding: Finding): FixSuggestion {
  const byCategory: Record<string, FixSuggestion> = {
    'Broken Object Level Authorization': {
      summary:
        'Add a server-side ownership/authorization check that verifies the authenticated principal is entitled to the requested object ID before returning data, rather than relying on the client-supplied ID alone.',
      patch: '// Pseudocode:\nif (resource.ownerId !== req.auth.userId) {\n  return res.status(403).json({ error: "Forbidden" });\n}',
    },
    Injection: {
      summary: 'Replace string-concatenated queries with parameterized queries / prepared statements, and validate input types server-side.',
      patch: '// Before: db.query(`SELECT * FROM t WHERE id = ${id}`)\n// After:  db.query("SELECT * FROM t WHERE id = ?", [id])',
    },
    'Security Misconfiguration': {
      summary: 'Set the missing security headers (Content-Security-Policy, Strict-Transport-Security, X-Content-Type-Options) at the reverse proxy or middleware layer, and disable directory indexing on static file servers.',
      patch: "// Express example:\napp.use(helmet());\napp.disable('x-powered-by');",
    },
    'Information Disclosure': {
      summary: 'Return a generic error message to clients and log full stack traces only server-side.',
      patch: '// Before: res.status(500).json({ error: err.stack })\n// After:  res.status(500).json({ error: "Internal server error" }); logger.error(err);',
    },
    'Secrets Management': {
      summary: 'Move the credential out of source control into an environment variable or secrets manager, then rotate the exposed credential.',
      patch: '// Before: const apiKey = "sk-xxxx";\n// After:  const apiKey = process.env.API_KEY;',
    },
    'Broken Access Control': {
      summary: 'Ensure every route is registered behind the authentication/authorization middleware for its required role before the handler executes.',
      patch: "app.get('/api/resource/:id', requireAuth, requireRole('user'), handler);",
    },
  };
  return (
    byCategory[finding.category] ?? {
      summary: 'Apply server-side validation and least-privilege checks appropriate to this finding, then re-run the retest.',
      patch: '// No category-specific template available — manual review recommended.',
    }
  );
}

function truncate(s: string, max: number): string {
  return s.length > max ? s.slice(0, max) + '\n... (truncated)' : s;
}
