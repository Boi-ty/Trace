/**
 * Trace Orchestration Server — entry point.
 */
import 'dotenv/config';
import express, { NextFunction, Request, Response } from 'express';
import cors from 'cors';
import { assessmentRouter } from './routes/assessment.routes';

const app = express();
const PORT = Number(process.env.PORT ?? 5000);

app.use(cors());
app.use(express.json({ limit: '2mb' }));

app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', service: 'trace-server', timestamp: new Date().toISOString() });
});

app.use('/api/assessments', assessmentRouter);

// Centralized error handler so an unexpected throw in any route becomes a
// clean JSON 500 instead of crashing the Node.js process.
app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  const message = err instanceof Error ? err.message : 'Internal server error.';
  // eslint-disable-next-line no-console
  console.error('[trace-server] Unhandled error:', message);
  if (!res.headersSent) {
    res.status(500).json({ error: message });
  }
});

process.on('unhandledRejection', (reason) => {
  // eslint-disable-next-line no-console
  console.error('[trace-server] Unhandled promise rejection:', reason);
});
process.on('uncaughtException', (err) => {
  // eslint-disable-next-line no-console
  console.error('[trace-server] Uncaught exception:', err);
});

app.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`[trace-server] Trace orchestration server listening on port ${PORT}`);
});
