/**
 * AI Retest Engine
 *
 * Given a previously discovered Finding, re-issues the exact HTTP request
 * against the live target and asks the AI service to decide whether the
 * vulnerability is now resolved (e.g. status changed 200 OK -> 403
 * Forbidden) or still present.
 */
import { AssessmentConfig, Finding, RetestResult } from '../types';
import { formatHttpResponse, safeRequest } from './httpClient';
import { evaluateRetest } from '../services/ai';

export async function executeRetest(finding: Finding, config: AssessmentConfig): Promise<RetestResult> {
  const timestamp = new Date().toISOString();

  try {
    const { method, url, headers } = parseStoredRequest(finding, config);

    const response = await safeRequest({ url, method, headers }, config.requestTimeoutMs);

    if (!response.ok) {
      return {
        findingId: finding.id,
        isResolved: false,
        newHttpResponse: `(request failed: ${response.error ?? 'unknown error'})`,
        aiExplanation:
          'The retest request could not reach the target. The finding is left unresolved pending a reachable target; this is not evidence either way.',
        timestamp,
      };
    }

    const newHttpResponse = formatHttpResponse(response.status, response.headers, truncate(response.raw, 2000));
    const evaluation = await evaluateRetest(finding, newHttpResponse);

    return {
      findingId: finding.id,
      isResolved: evaluation.isResolved,
      newHttpResponse,
      aiExplanation: evaluation.explanation,
      timestamp,
    };
  } catch (err: unknown) {
    // A retest must never throw and take down the server — always resolve
    // with a safe "could not verify" result instead.
    const message = err instanceof Error ? err.message : 'Unknown retest error';
    return {
      findingId: finding.id,
      isResolved: false,
      newHttpResponse: `(retest error: ${message})`,
      aiExplanation: 'An internal error occurred while running the retest. Please try again.',
      timestamp,
    };
  }
}

/**
 * Reconstructs enough of the original request (method, URL, auth header)
 * from the stored finding + current config to replay it. TraceLogic
 * findings replay with User B's token (the cross-tenant probe); all other
 * findings replay as a plain GET with User A's token.
 */
function parseStoredRequest(
  finding: Finding,
  config: AssessmentConfig
): { method: string; url: string; headers: Record<string, string> } {
  const base = config.targetUrl.replace(/\/+$/, '');
  const endpointPath = finding.endpoint.startsWith('/') ? finding.endpoint : `/${finding.endpoint}`;
  const url = `${base}${endpointPath}`;
  const method = finding.method && finding.method !== 'STATIC' ? finding.method : 'GET';

  const headers: Record<string, string> =
    finding.agent === 'TraceLogic'
      ? { Authorization: `Bearer ${config.userBToken}`, Accept: 'application/json', 'X-Tenant': 'tenant-b' }
      : { Authorization: `Bearer ${config.userAToken}`, Accept: 'application/json' };

  return { method, url, headers };
}

function truncate(s: string, max: number): string {
  return s.length > max ? s.slice(0, max) + '\n... (truncated)' : s;
}
