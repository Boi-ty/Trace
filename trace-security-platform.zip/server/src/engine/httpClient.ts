/**
 * Thin, defensive HTTP wrapper shared by every engine module.
 *
 * Every live-target request goes through here so that timeouts, redirect
 * limits, and failure handling are consistent, and so a single unreachable
 * or slow target can never crash the orchestrator or hang a scan.
 */
import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';

export interface SafeResponse {
  ok: boolean;
  status: number;
  headers: Record<string, string>;
  data: unknown;
  raw: string;
  error?: string;
  elapsedMs: number;
}

const DEFAULT_TIMEOUT_MS = Number(process.env.REQUEST_TIMEOUT_MS ?? 8000);

export async function safeRequest(
  config: AxiosRequestConfig & { url: string },
  timeoutMs: number = DEFAULT_TIMEOUT_MS
): Promise<SafeResponse> {
  const started = Date.now();
  try {
    const response: AxiosResponse = await axios({
      ...config,
      timeout: timeoutMs,
      maxRedirects: 3,
      validateStatus: () => true, // never throw on 4xx/5xx — we want to inspect them
    });
    return {
      ok: true,
      status: response.status,
      headers: normalizeHeaders(response.headers),
      data: response.data,
      raw: stringifyBody(response.data),
      elapsedMs: Date.now() - started,
    };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown request error';
    return {
      ok: false,
      status: 0,
      headers: {},
      data: null,
      raw: '',
      error: message,
      elapsedMs: Date.now() - started,
    };
  }
}

function normalizeHeaders(headers: unknown): Record<string, string> {
  const out: Record<string, string> = {};
  if (headers && typeof headers === 'object') {
    for (const [k, v] of Object.entries(headers as Record<string, unknown>)) {
      out[k] = String(v);
    }
  }
  return out;
}

function stringifyBody(data: unknown): string {
  try {
    if (typeof data === 'string') return data;
    return JSON.stringify(data, null, 2);
  } catch {
    return String(data);
  }
}

/**
 * Formats a request/response pair as a readable HTTP-wire-style string,
 * used to populate Finding.httpRequest / Finding.httpResponse and the
 * Inspector Panel's raw viewer.
 */
export function formatHttpRequest(
  method: string,
  url: string,
  headers: Record<string, string>,
  body?: string
): string {
  let host = url;
  let path = url;
  try {
    const u = new URL(url);
    host = u.host;
    path = u.pathname + u.search;
  } catch {
    // leave as-is if URL parsing fails
  }
  const headerLines = Object.entries(headers)
    .map(([k, v]) => `${k}: ${redactSensitive(k, v)}`)
    .join('\n');
  return [`${method.toUpperCase()} ${path} HTTP/1.1`, `Host: ${host}`, headerLines, '', body ?? '']
    .filter((l) => l !== undefined)
    .join('\n');
}

export function formatHttpResponse(status: number, headers: Record<string, string>, body: string): string {
  const headerLines = Object.entries(headers)
    .map(([k, v]) => `${k}: ${v}`)
    .join('\n');
  return [`HTTP/1.1 ${status} ${statusText(status)}`, headerLines, '', body].join('\n');
}

function statusText(status: number): string {
  const map: Record<number, string> = {
    200: 'OK',
    201: 'Created',
    204: 'No Content',
    301: 'Moved Permanently',
    400: 'Bad Request',
    401: 'Unauthorized',
    403: 'Forbidden',
    404: 'Not Found',
    429: 'Too Many Requests',
    500: 'Internal Server Error',
    502: 'Bad Gateway',
    503: 'Service Unavailable',
  };
  return map[status] ?? '';
}

/** Never let a bearer token or API key leak verbatim into stored proof text. */
function redactSensitive(key: string, value: string): string {
  if (/authorization|token|api-key|cookie/i.test(key)) {
    if (value.length <= 12) return '***redacted***';
    return `${value.slice(0, 10)}...${value.slice(-4)}`;
  }
  return value;
}
