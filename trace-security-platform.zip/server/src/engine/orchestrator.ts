/**
 * Trace Orchestration Engine
 *
 * Coordinates parallel execution of TraceCode (SAST), TraceProbe (DAST),
 * and TraceLogic (Auth/IDOR), aggregates findings into the in-memory
 * assessment store, and broadcasts live progress over Server-Sent Events.
 */
import { Assessment, AssessmentConfig, Finding, ModuleName, ProgressEvent } from '../types';
import { runSastScan } from './modules/code';
import { runDastScan } from './modules/probe';
import { runIdorCheck } from './modules/logic';

type Listener = (event: ProgressEvent) => void;

class Orchestrator {
  private assessments = new Map<string, Assessment>();
  private listeners = new Map<string, Set<Listener>>();

  createAssessment(config: AssessmentConfig): Assessment {
    const assessment: Assessment = {
      config,
      status: 'PENDING',
      findings: [],
      retestLogs: [],
    };
    this.assessments.set(config.id, assessment);
    return assessment;
  }

  getAssessment(id: string): Assessment | undefined {
    return this.assessments.get(id);
  }

  subscribe(assessmentId: string, listener: Listener): () => void {
    if (!this.listeners.has(assessmentId)) this.listeners.set(assessmentId, new Set());
    this.listeners.get(assessmentId)!.add(listener);
    return () => this.listeners.get(assessmentId)?.delete(listener);
  }

  recordRetest(assessmentId: string, findingId: string, isResolved: boolean): void {
    const assessment = this.assessments.get(assessmentId);
    if (!assessment) return;
    const finding = assessment.findings.find((f) => f.id === findingId);
    if (finding) finding.status = isResolved ? 'VERIFIED_FIXED' : 'FAILED_RETEST';
  }

  /** Fire-and-forget: starts the scan and streams progress; errors are caught per-agent. */
  async runAssessment(config: AssessmentConfig): Promise<void> {
    const assessment = this.assessments.get(config.id);
    if (!assessment) return;

    assessment.status = 'RUNNING';
    assessment.startedAt = new Date().toISOString();
    this.emit(config.id, { type: 'log', message: 'Assessment started.', agent: 'orchestrator' });

    const modules = config.selectedModules?.length
      ? config.selectedModules
      : (['TraceCode', 'TraceProbe', 'TraceLogic'] as ModuleName[]);

    const jobs: Promise<void>[] = [];

    if (modules.includes('TraceCode')) jobs.push(this.runModule(config, 'TraceCode', runSastScan));
    if (modules.includes('TraceProbe')) jobs.push(this.runModule(config, 'TraceProbe', runDastScan));
    if (modules.includes('TraceLogic')) jobs.push(this.runModule(config, 'TraceLogic', runIdorCheck));

    try {
      await Promise.allSettled(jobs);
      assessment.status = 'COMPLETED';
      assessment.completedAt = new Date().toISOString();
      this.emit(config.id, {
        type: 'assessment_complete',
        message: `Scan complete. ${assessment.findings.length} findings.`,
      });
    } catch (err) {
      // Promise.allSettled never rejects, but guard anyway so a bug here
      // can't leave the assessment stuck in RUNNING forever.
      assessment.status = 'FAILED';
      const message = err instanceof Error ? err.message : 'Unknown orchestrator error';
      this.emit(config.id, { type: 'error', message });
    }
  }

  private async runModule(
    config: AssessmentConfig,
    agent: ModuleName,
    runner: (config: AssessmentConfig) => Promise<Finding[]>
  ): Promise<void> {
    this.emit(config.id, { type: 'agent_status', agent, message: `${agent} started.`, progress: 0 });
    try {
      const findings = await runner(config);
      const assessment = this.assessments.get(config.id);
      if (assessment) {
        assessment.findings.push(...findings);
        for (const finding of findings) {
          this.emit(config.id, { type: 'finding', agent, finding });
        }
      }
      this.emit(config.id, { type: 'agent_status', agent, message: `${agent} completed.`, progress: 100 });
    } catch (err) {
      // Each engine already catches its own errors; this is a last-resort
      // guard so one misbehaving module never kills the whole assessment.
      const message = err instanceof Error ? err.message : `${agent} failed unexpectedly.`;
      this.emit(config.id, { type: 'error', agent, message });
    }
  }

  private emit(assessmentId: string, partial: Omit<ProgressEvent, 'assessmentId' | 'timestamp'>): void {
    const event: ProgressEvent = { ...partial, assessmentId, timestamp: new Date().toISOString() };
    const subs = this.listeners.get(assessmentId);
    if (!subs) return;
    for (const listener of subs) {
      try {
        listener(event);
      } catch {
        // A broken SSE connection must not affect other listeners.
      }
    }
  }
}

// Singleton: one orchestrator per server process, shared across routes.
export const orchestrator = new Orchestrator();
