/**
 * TraceCode — Static Application Security Testing (SAST) Engine
 *
 * Walks a locally-available checkout of `config.targetRepo` (the user is
 * expected to have cloned/mounted it; this module never attempts to clone
 * an arbitrary remote itself) and applies conservative, pattern-based
 * checks for hardcoded secrets, unsafe DB calls, and missing authorization
 * middleware. This mirrors the "parse ASTs" step from the architecture doc
 * at a lightweight, regex-based level suitable for a demo/orchestration
 * harness; swapping in a real parser (e.g. Semgrep, run out-of-process) is
 * a drop-in replacement for `scanFile` below.
 */
import * as fs from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { AssessmentConfig, Finding } from '../../types';

const SCAN_EXTENSIONS = new Set(['.ts', '.tsx', '.js', '.jsx', '.py']);
const IGNORE_DIRS = new Set(['node_modules', '.git', 'dist', 'build', '.next', 'coverage']);
const MAX_FILES = 2000;

interface PatternRule {
  regex: RegExp;
  title: string;
  severity: Finding['severity'];
  category: string;
  description: string;
}

const RULES: PatternRule[] = [
  {
    regex: /(api[_-]?key|secret|password|token)\s*[:=]\s*['"][A-Za-z0-9_\-/+=]{8,}['"]/i,
    title: 'Hardcoded Credentials',
    severity: 'MEDIUM',
    category: 'Secrets Management',
    description: 'A credential-like literal (API key, password, or token) appears hardcoded in source code.',
  },
  {
    regex: /\b(query|execute)\s*\(\s*(['"`])[^'"`]*\$\{[^}]+\}[^'"`]*\2/,
    title: 'Potential SQL Injection via String Interpolation',
    severity: 'HIGH',
    category: 'Injection',
    description: 'A database query appears to be built with string interpolation rather than parameterized placeholders.',
  },
  {
    regex: /app\.(get|post|put|delete|patch)\(\s*['"`][^'"`]+['"`]\s*,\s*(async\s*)?\(?\s*req/i,
    title: 'Route Possibly Missing Authorization Middleware',
    severity: 'HIGH',
    category: 'Broken Access Control',
    description: 'A route handler is registered without an authentication/authorization middleware argument before the handler.',
  },
  {
    regex: /res\.(json|send)\([^)]*error(?:\.stack|Stack)?\b/i,
    title: 'Verbose Error Exposed to Client',
    severity: 'LOW',
    category: 'Information Disclosure',
    description: 'An error object (potentially including a stack trace) is sent directly in the HTTP response.',
  },
];

export async function runSastScan(config: AssessmentConfig): Promise<Finding[]> {
  const findings: Finding[] = [];
  const repoPath = resolveLocalRepoPath(config.targetRepo);

  if (!repoPath || !fs.existsSync(repoPath)) {
    // No local checkout available — skip gracefully rather than attempting
    // to clone an arbitrary remote URL from inside the engine.
    return findings;
  }

  try {
    const files = walkDirectory(repoPath, MAX_FILES);
    for (const file of files) {
      const fileFindings = scanFile(file, repoPath, config.id);
      findings.push(...fileFindings);
    }
  } catch (err) {
    // A single unreadable file or permissions error must not crash the scan.
    return findings;
  }

  return findings;
}

function scanFile(filePath: string, repoRoot: string, assessmentId: string): Finding[] {
  const out: Finding[] = [];
  let content: string;
  try {
    content = fs.readFileSync(filePath, 'utf-8');
  } catch {
    return out;
  }

  const lines = content.split('\n');
  const relativePath = path.relative(repoRoot, filePath);

  lines.forEach((line, idx) => {
    for (const rule of RULES) {
      if (rule.regex.test(line)) {
        out.push({
          id: uuidv4(),
          assessmentId,
          title: rule.title,
          severity: rule.severity,
          category: rule.category,
          endpoint: `${relativePath}:${idx + 1}`,
          method: 'STATIC',
          agent: 'TraceCode',
          description: rule.description,
          httpRequest: '(static analysis finding — no HTTP request involved)',
          httpResponse: '(static analysis finding — no HTTP response involved)',
          proof: `${relativePath} line ${idx + 1}: ${line.trim().slice(0, 200)}`,
          status: 'OPEN',
          discoveredAt: new Date().toISOString(),
        });
      }
    }
  });

  return out;
}

function walkDirectory(root: string, maxFiles: number): string[] {
  const results: string[] = [];
  const stack: string[] = [root];

  while (stack.length > 0 && results.length < maxFiles) {
    const current = stack.pop() as string;
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const entry of entries) {
      if (results.length >= maxFiles) break;
      const fullPath = path.join(current, entry.name);
      if (entry.isDirectory()) {
        if (!IGNORE_DIRS.has(entry.name)) stack.push(fullPath);
      } else if (SCAN_EXTENSIONS.has(path.extname(entry.name))) {
        results.push(fullPath);
      }
    }
  }
  return results;
}

/**
 * `targetRepo` arrives as a repository reference (e.g. a GitHub URL or a
 * local path). TraceCode only operates on local paths it can read; for a
 * remote URL it looks for a conventional local checkout the operator has
 * already placed at ./repos/<repo-name> relative to the server working
 * directory, and otherwise returns null so the orchestrator skips SAST
 * cleanly instead of fabricating findings.
 */
function resolveLocalRepoPath(targetRepo: string): string | null {
  if (!targetRepo) return null;
  if (fs.existsSync(targetRepo)) return targetRepo;

  try {
    const name = targetRepo.replace(/\.git$/, '').split('/').filter(Boolean).pop();
    if (!name) return null;
    const candidate = path.join(process.cwd(), 'repos', name);
    return fs.existsSync(candidate) ? candidate : null;
  } catch {
    return null;
  }
}
