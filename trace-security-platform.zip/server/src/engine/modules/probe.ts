/**
 * TraceProbe — Dynamic Application Security Testing (DAST) Engine
 *
 * Crawls a small set of likely endpoints on the live target and checks for
 * two conservative, non-destructive signal classes:
 *   1. Missing/weak security headers (CSP, HSTS, X-Content-Type-Options).
 *   2. Verbose error / stack-trace leakage on malformed requests.
 *
 * This module deliberately does NOT attempt real injection/exploitation
 * payloads (SQLi, XSS, command injection) against arbitrary user-supplied
 * targets — that class of active fuzzing belongs to a dedicated, rate- and
 * scope-limited tool (e.g. Nuclei/ffuf per the architecture doc) run by the
 * operator against an environment they've confirmed is in scope, not to
 * code generated here. TraceProbe instead reports configuration-level
 * weaknesses it can detect safely with ordinary GET requests.
 */
import { v4 as uuidv4 } from 'uuid';
import { AssessmentConfig, Finding } from '../../types';
import { formatHttpRequest, formatHttpResponse, safeRequest } from '../httpClient';

const PROBE_PATHS = ['/', '/api/search', '/api/debug', '/static/', '/api/health'];

const REQUIRED_HEADERS: { header: string; title: string; description: string }[] = [
  {
    header: 'content-security-policy',
    title: 'Missing Content-Security-Policy Header',
    description: 'The application does not set a Content-Security-Policy header, increasing exposure to XSS and data-injection attacks.',
  },
  {
    header: 'strict-transport-security',
    title: 'Missing HSTS Header',
    description: 'The application does not set Strict-Transport-Security, allowing downgrade to plain HTTP on supporting clients.',
  },
  {
    header: 'x-content-type-options',
    title: 'Missing X-Content-Type-Options Header',
    description: 'The application does not set X-Content-Type-Options: nosniff, allowing MIME-sniffing based attacks in some browsers.',
  },
];

export async function runDastScan(config: AssessmentConfig): Promise<Finding[]> {
  const findings: Finding[] = [];
  if (!config.targetUrl) return findings;

  const base = config.targetUrl.replace(/\/+$/, '');

  // 1. Header audit on the root document.
  try {
    const rootUrl = `${base}/`;
    const res = await safeRequest({ url: rootUrl, method: 'GET', headers: { Accept: 'text/html' } }, config.requestTimeoutMs);
    if (res.ok) {
      const headerKeysLower = new Set(Object.keys(res.headers).map((h) => h.toLowerCase()));
      const missing = REQUIRED_HEADERS.filter((h) => !headerKeysLower.has(h.header));
      if (missing.length > 0) {
        findings.push(
          buildHeaderFinding(config.id, rootUrl, res.status, res.headers, missing.map((m) => m.header))
        );
      }
    }
  } catch {
    // Non-fatal: header audit is best-effort.
  }

  // 2. Verbose error check: request a path likely to 404/500 and see if the
  //    body leaks a stack trace or internal file path.
  for (const path of PROBE_PATHS.slice(1)) {
    try {
      const url = `${base}${path}`;
      const res = await safeRequest({ url, method: 'GET', headers: { Accept: 'application/json' } }, config.requestTimeoutMs);
      if (!res.ok) continue;

      if (res.status >= 400 && looksLikeStackTrace(res.raw)) {
        findings.push(buildVerboseErrorFinding(config.id, url, res.status, res.headers, res.raw));
      }
      if (path === '/static/' && res.status === 200 && looksLikeDirectoryListing(res.raw)) {
        findings.push(buildDirectoryListingFinding(config.id, url, res.status, res.headers, res.raw));
      }
    } catch {
      continue;
    }
  }

  return findings;
}

function buildHeaderFinding(
  assessmentId: string,
  url: string,
  status: number,
  headers: Record<string, string>,
  missingHeaders: string[]
): Finding {
  return {
    id: uuidv4(),
    assessmentId,
    title: 'Missing Security Headers',
    severity: 'MEDIUM',
    category: 'Security Misconfiguration',
    endpoint: '/',
    method: 'GET',
    agent: 'TraceProbe',
    description: `CSP and/or HSTS not configured. Missing headers: ${missingHeaders.join(', ')}.`,
    httpRequest: formatHttpRequest('GET', url, { Accept: 'text/html' }),
    httpResponse: formatHttpResponse(status, headers, '(headers inspected, body omitted)'),
    proof: `Response headers lacked: ${missingHeaders.join(', ')}, weakening the browser-side security posture.`,
    status: 'OPEN',
    discoveredAt: new Date().toISOString(),
  };
}

function buildVerboseErrorFinding(
  assessmentId: string,
  url: string,
  status: number,
  headers: Record<string, string>,
  raw: string
): Finding {
  return {
    id: uuidv4(),
    assessmentId,
    title: 'Verbose Error Messages',
    severity: 'LOW',
    category: 'Information Disclosure',
    endpoint: new URL(url).pathname,
    method: 'GET',
    agent: 'TraceProbe',
    description: 'Stack traces or internal file paths are exposed in error responses, aiding attacker reconnaissance.',
    httpRequest: formatHttpRequest('GET', url, { Accept: 'application/json' }),
    httpResponse: formatHttpResponse(status, headers, truncate(raw, 1000)),
    proof: 'The error response body contains stack-trace-like content (file paths / line numbers / framework internals).',
    status: 'OPEN',
    discoveredAt: new Date().toISOString(),
  };
}

function buildDirectoryListingFinding(
  assessmentId: string,
  url: string,
  status: number,
  headers: Record<string, string>,
  raw: string
): Finding {
  return {
    id: uuidv4(),
    assessmentId,
    title: 'Directory Listing',
    severity: 'LOW',
    category: 'Security Misconfiguration',
    endpoint: new URL(url).pathname,
    method: 'GET',
    agent: 'TraceProbe',
    description: 'Public directory listing is not restricted, potentially exposing unintended files.',
    httpRequest: formatHttpRequest('GET', url, { Accept: 'text/html' }),
    httpResponse: formatHttpResponse(status, headers, truncate(raw, 800)),
    proof: 'The static path returned an auto-generated directory index instead of a 403/404.',
    status: 'OPEN',
    discoveredAt: new Date().toISOString(),
  };
}

function looksLikeStackTrace(body: string): boolean {
  return /at\s+\S+\s+\(.*:\d+:\d+\)|Traceback \(most recent call last\)|Exception in thread|\.java:\d+\)|node_modules\//i.test(
    body
  );
}

function looksLikeDirectoryListing(body: string): boolean {
  return /Index of \/|<title>Directory listing/i.test(body);
}

function truncate(s: string, max: number): string {
  return s.length > max ? s.slice(0, max) + '\n... (truncated)' : s;
}
