/**
 * TraceLogic — Auth & IDOR Engine
 *
 * Replays authenticated requests belonging to one principal (User A) while
 * substituting another principal's credentials (User B) to detect
 * Insecure Direct Object Reference / Broken Object Level Authorization
 * flaws: cases where the server returns another tenant's data instead of
 * enforcing an ownership check.
 *
 * This module only talks to `config.targetUrl` and only uses the tokens the
 * user explicitly supplied for their own authorized assessment target.
 */
import { v4 as uuidv4 } from 'uuid';
import { AssessmentConfig, Finding } from '../../types';
import { formatHttpRequest, formatHttpResponse, safeRequest } from '../httpClient';

interface CandidateEndpoint {
  method: string;
  path: string;
  /** A numeric-ish id segment we'll try swapping, e.g. "456" in /api/users/456 */
  idHint: string;
}

/**
 * A small, safe default set of object-reference shaped endpoints to probe
 * when the user hasn't supplied an OpenAPI/Swagger schema. Real deployments
 * would derive this list from recon (Step 2 in the architecture doc); here
 * we keep a conservative, read-mostly default list so the engine degrades
 * gracefully against any target without a spec.
 */
const DEFAULT_CANDIDATES: CandidateEndpoint[] = [
  { method: 'GET', path: '/api/users/{id}', idHint: '456' },
  { method: 'GET', path: '/api/orders/{id}', idHint: '1002' },
  { method: 'GET', path: '/api/accounts/{id}', idHint: '77' },
  { method: 'GET', path: '/api/tenants/{id}/resources', idHint: '12' },
  { method: 'GET', path: '/api/invoices/{id}', idHint: '203' },
];

export async function runIdorCheck(config: AssessmentConfig): Promise<Finding[]> {
  const findings: Finding[] = [];

  if (!config.targetUrl) {
    return findings;
  }
  if (!config.userAToken || !config.userBToken) {
    // IDOR testing requires two distinct principals; skip safely rather than
    // guessing or fabricating a token.
    return findings;
  }

  const base = config.targetUrl.replace(/\/+$/, '');
  const concurrency = Math.max(1, Math.min(config.maxConcurrentRequests ?? 3, 5));

  const batches = chunk(DEFAULT_CANDIDATES, concurrency);
  for (const batch of batches) {
    const results = await Promise.all(batch.map((candidate) => testCandidate(base, candidate, config)));
    for (const finding of results) {
      if (finding) findings.push(finding);
    }
  }

  return findings;
}

async function testCandidate(
  base: string,
  candidate: CandidateEndpoint,
  config: AssessmentConfig
): Promise<Finding | null> {
  const path = candidate.path.replace('{id}', candidate.idHint);
  const url = `${base}${path}`;

  try {
    // 1. Establish a baseline: User A reading their own (presumed) resource.
    const baselineHeaders = { Authorization: `Bearer ${config.userAToken}`, Accept: 'application/json' };
    const baseline = await safeRequest({ url, method: candidate.method, headers: baselineHeaders }, config.requestTimeoutMs);

    if (!baseline.ok) {
      // Target unreachable for this path — skip rather than fail the whole scan.
      return null;
    }
    if (baseline.status === 404) {
      // Endpoint doesn't exist on this target; nothing to test.
      return null;
    }

    // 2. Replay the identical request, substituting User B's token.
    const crossHeaders = { Authorization: `Bearer ${config.userBToken}`, Accept: 'application/json', 'X-Tenant': 'tenant-b' };
    const cross = await safeRequest({ url, method: candidate.method, headers: crossHeaders }, config.requestTimeoutMs);

    if (!cross.ok) return null;

    const isLeak = cross.status === 200 && looksLikeTenantData(cross.raw, baseline.raw);
    if (!isLeak) return null;

    const httpRequest = formatHttpRequest(candidate.method, url, crossHeaders);
    const httpResponse = formatHttpResponse(cross.status, cross.headers, truncate(cross.raw, 2000));

    const finding: Finding = {
      id: uuidv4(),
      assessmentId: config.id,
      title: `IDOR - ${resourceNameFromPath(path)}`,
      severity: 'CRITICAL',
      category: 'Broken Object Level Authorization',
      endpoint: path,
      method: candidate.method,
      agent: 'TraceLogic',
      description: `The application allows access to ${resourceNameFromPath(
        path
      )} data by modifying the resource identifier in the endpoint, without proper authorization checks, enabling Insecure Direct Object Reference (IDOR).`,
      httpRequest,
      httpResponse,
      proof: `The response returned HTTP ${cross.status} with data while using a token belonging to a different account/tenant, confirming the IDOR vulnerability and cross-tenant data exposure.`,
      status: 'OPEN',
      discoveredAt: new Date().toISOString(),
    };
    return finding;
  } catch (err) {
    // Defensive catch-all: a single bad endpoint must never crash the scan.
    return null;
  }
}

/**
 * Heuristic: if the response looks like structured object data (not an
 * empty shell, error envelope, or a page identical to an access-denied
 * response) and didn't come back as 401/403, treat it as a plausible leak.
 * A production engine would also diff against an authenticated 403 baseline
 * obtained with an invalid token; we approximate that here with simple
 * shape checks to keep this module dependency-free.
 */
function looksLikeTenantData(raw: string, baselineRaw: string): boolean {
  if (!raw || raw.length < 2) return false;
  const deniedMarkers = /forbidden|unauthorized|access denied|not permitted/i;
  if (deniedMarkers.test(raw)) return false;
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      const keys = Array.isArray(parsed) ? Object.keys(parsed[0] ?? {}) : Object.keys(parsed);
      return keys.length > 0;
    }
  } catch {
    // Non-JSON bodies: fall back to a length/shape comparison against baseline.
    return raw.length > 10 && raw !== baselineRaw;
  }
  return false;
}

function resourceNameFromPath(path: string): string {
  const segment = path.split('/').filter(Boolean)[1] ?? 'User Data';
  return segment.replace(/^./, (c) => c.toUpperCase()) + ' Data Access';
}

function truncate(s: string, max: number): string {
  return s.length > max ? s.slice(0, max) + '\n... (truncated)' : s;
}

function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}
