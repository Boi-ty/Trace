/**
 * Shared type definitions for the Trace Security Platform.
 *
 * These interfaces describe assessment configuration, normalized findings
 * produced by any of the three engines (TraceCode, TraceProbe, TraceLogic),
 * and the result of an AI-driven retest.
 */

export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';

export type AgentName = 'TraceCode' | 'TraceProbe' | 'TraceLogic';

export type FindingStatus = 'OPEN' | 'VERIFIED_FIXED' | 'FAILED_RETEST';

export type AssessmentStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED';

export type ModuleName = 'TraceCode' | 'TraceProbe' | 'TraceLogic';

/**
 * Configuration submitted by the user when starting a new assessment.
 */
export interface AssessmentConfig {
  id: string;
  targetRepo: string;
  targetUrl: string;
  userAToken: string;
  userBToken: string;
  selectedModules: ModuleName[];
  createdAt: string;
  /** Soft request cap, enforced by every engine that talks to targetUrl. */
  maxConcurrentRequests?: number;
  requestTimeoutMs?: number;
}

/**
 * A single normalized security finding, regardless of which agent produced it.
 */
export interface Finding {
  id: string;
  assessmentId: string;
  title: string;
  severity: Severity;
  category: string;
  endpoint: string;
  method: string;
  agent: AgentName;
  description: string;
  httpRequest: string;
  httpResponse: string;
  proof: string;
  status: FindingStatus;
  discoveredAt: string;
}

/**
 * The outcome of re-issuing a finding's request to confirm whether a fix
 * actually closed the vulnerability.
 */
export interface RetestResult {
  findingId: string;
  isResolved: boolean;
  newHttpResponse: string;
  aiExplanation: string;
  timestamp: string;
}

/**
 * Live progress event broadcast over SSE while an assessment runs.
 */
export interface ProgressEvent {
  type: 'agent_status' | 'finding' | 'log' | 'assessment_complete' | 'error';
  agent?: AgentName | 'orchestrator';
  message?: string;
  progress?: number; // 0-100
  finding?: Finding;
  assessmentId: string;
  timestamp: string;
}

/**
 * In-memory assessment record tracked by the orchestrator.
 */
export interface Assessment {
  config: AssessmentConfig;
  status: AssessmentStatus;
  findings: Finding[];
  retestLogs: RetestResult[];
  startedAt?: string;
  completedAt?: string;
}
