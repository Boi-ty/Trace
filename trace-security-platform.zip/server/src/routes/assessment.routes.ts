/**
 * /api/assessments routes
 *
 * POST   /api/assessments                       create + kick off a scan
 * GET    /api/assessments/:id                    fetch current state (poll fallback)
 * GET    /api/assessments/:id/stream             SSE live progress
 * POST   /api/assessments/:id/retest/:findingId  run a targeted retest
 */
import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { AssessmentConfig, ModuleName } from '../types';
import { orchestrator } from '../engine/orchestrator';
import { executeRetest } from '../engine/retestAgent';

export const assessmentRouter = Router();

assessmentRouter.post('/', (req: Request, res: Response) => {
  try {
    const body = req.body ?? {};
    const { targetRepo, targetUrl, userAToken, userBToken, selectedModules } = body;

    if (!targetUrl && !targetRepo) {
      return res.status(400).json({ error: 'At least one of targetUrl or targetRepo is required.' });
    }

    const config: AssessmentConfig = {
      id: uuidv4(),
      targetRepo: targetRepo ?? '',
      targetUrl: targetUrl ?? '',
      userAToken: userAToken ?? '',
      userBToken: userBToken ?? '',
      selectedModules: Array.isArray(selectedModules) && selectedModules.length
        ? (selectedModules as ModuleName[])
        : (['TraceCode', 'TraceProbe', 'TraceLogic'] as ModuleName[]),
      createdAt: new Date().toISOString(),
      maxConcurrentRequests: Number(process.env.MAX_CONCURRENT_REQUESTS ?? 3),
      requestTimeoutMs: Number(process.env.REQUEST_TIMEOUT_MS ?? 8000),
    };

    const assessment = orchestrator.createAssessment(config);

    // Fire-and-forget; the client follows progress via the SSE stream.
    orchestrator.runAssessment(config).catch(() => {
      /* runAssessment already guards internally; this is a final backstop */
    });

    return res.status(201).json({ id: config.id, status: assessment.status, createdAt: config.createdAt });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to create assessment.';
    return res.status(500).json({ error: message });
  }
});

assessmentRouter.get('/:id', (req: Request, res: Response) => {
  const assessment = orchestrator.getAssessment(req.params.id);
  if (!assessment) return res.status(404).json({ error: 'Assessment not found.' });
  return res.json(assessment);
});

assessmentRouter.get('/:id/stream', (req: Request, res: Response) => {
  const assessmentId = req.params.id;
  const assessment = orchestrator.getAssessment(assessmentId);
  if (!assessment) {
    res.status(404).json({ error: 'Assessment not found.' });
    return;
  }

  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
  });
  res.write('retry: 2000\n\n');

  // Replay anything already discovered before this client connected.
  for (const finding of assessment.findings) {
    res.write(`data: ${JSON.stringify({ type: 'finding', finding, assessmentId, timestamp: new Date().toISOString() })}\n\n`);
  }

  const unsubscribe = orchestrator.subscribe(assessmentId, (event) => {
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  });

  const heartbeat = setInterval(() => {
    try {
      res.write(': heartbeat\n\n');
    } catch {
      clearInterval(heartbeat);
    }
  }, 15000);

  req.on('close', () => {
    clearInterval(heartbeat);
    unsubscribe();
    res.end();
  });
});

assessmentRouter.post('/:id/retest/:findingId', async (req: Request, res: Response) => {
  try {
    const { id, findingId } = req.params;
    const assessment = orchestrator.getAssessment(id);
    if (!assessment) return res.status(404).json({ error: 'Assessment not found.' });

    const finding = assessment.findings.find((f) => f.id === findingId);
    if (!finding) return res.status(404).json({ error: 'Finding not found.' });

    const result = await executeRetest(finding, assessment.config);
    assessment.retestLogs.push(result);
    orchestrator.recordRetest(id, findingId, result.isResolved);

    return res.json(result);
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Retest failed unexpectedly.';
    return res.status(500).json({ error: message });
  }
});
