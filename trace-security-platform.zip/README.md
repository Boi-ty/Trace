# Trace — Automated Security Assessment Platform

**Real Exploits. Not Just Alerts.**

Trace coordinates three security engines — **TraceCode** (SAST), **TraceProbe** (DAST), and
**TraceLogic** (Auth/IDOR) — and verifies remediations with an AI-driven **Retest Engine**.

## ⚠️ Authorized use only

Only run assessments against targets you are explicitly authorized to test: your own
staging/dev environments, or deliberately vulnerable apps such as [OWASP Juice
Shop](https://owasp.org/www-project-juice-shop/) or WebGoat. Do not point `targetUrl` at
systems you do not own or have written permission to test.

## Project layout

```
trace-security-platform/
├── server/   Express + TypeScript orchestration API
│   └── src/
│       ├── types.ts              Shared data models
│       ├── server.ts              Entry point
│       ├── routes/
│       │   └── assessment.routes.ts
│       ├── engine/
│       │   ├── orchestrator.ts   Parallel agent coordinator + SSE broadcaster
│       │   ├── retestAgent.ts    AI-driven retest verification
│       │   ├── httpClient.ts     Shared safe HTTP wrapper (timeouts, redaction)
│       │   └── modules/
│       │       ├── code.ts       TraceCode (SAST) — pattern-based static analysis
│       │       ├── probe.ts      TraceProbe (DAST) — header/error audits
│       │       └── logic.ts      TraceLogic (IDOR/BOLA token-swap replay)
│       └── services/
│           └── ai.ts             Ollama / cloud LLM wrapper with deterministic fallback
└── client/   React + Vite + Tailwind dashboard
    └── src/
        ├── components/
        │   ├── Dashboard.tsx      Top-level layout, scan setup, state orchestration
        │   ├── AgentCard.tsx      Live per-agent status card
        │   ├── FindingList.tsx    Severity-grouped findings list
        │   ├── InspectorPanel.tsx HTTP request/response viewer + proof box
        │   └── RetestStudio.tsx   Retest drawer with PASS/FAIL verdict + diff
        └── services/api.ts        Fetch + SSE client
```

## Running it

### 1. Backend

```bash
cd server
npm install
cp .env.example .env     # optional: point at a local Ollama instance
npm run dev               # http://localhost:5000
```

### 2. Frontend

```bash
cd client
npm install
npm run dev               # http://localhost:5173 (proxies /api to :5000)
```

Open http://localhost:5173, fill in a target API base URL (and, for IDOR testing, a
User A / User B bearer token pair), and click **Run TRACE Scan**.

## AI integration

`server/src/services/ai.ts` first tries a local [Ollama](https://ollama.com) instance
(`OLLAMA_BASE_URL`, default `http://localhost:11434`, model `llama3` by default). If Ollama
isn't running, it falls back to a generic cloud endpoint if `AI_API_URL`/`AI_API_KEY` are set,
and finally to deterministic status-code/body heuristics — so retests always return a verdict,
even fully offline.

## How TraceLogic detects IDOR

For each candidate object-reference endpoint (e.g. `GET /api/users/{id}`), TraceLogic:

1. Requests the resource with **User A**'s token (baseline).
2. Replays the identical request with **User B**'s token.
3. Flags a finding if the cross-account request still returns `200 OK` with structured data
   instead of a `401`/`403`.

Retesting an IDOR finding re-issues the same cross-account request; a `401`/`403`/`404` on
retest is treated as resolved.

## Notes on scope

- `TraceCode` scans a **local checkout** of `targetRepo` (place it at `server/repos/<name>`,
  or pass a local path directly) — it never clones an arbitrary remote itself.
- `TraceProbe` only performs safe, read-only header/error-disclosure checks here; wiring in
  heavier fuzzers (Nuclei/ffuf) per the original architecture doc is a drop-in extension of
  `server/src/engine/modules/probe.ts` and should only be pointed at environments you control.
- All engines catch their own errors — an unreachable target degrades a scan's findings, it
  never crashes the Node process (verified: see smoke test in this session's history).
