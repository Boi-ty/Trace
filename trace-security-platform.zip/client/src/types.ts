/** Mirrors server/src/types.ts for the frontend (kept in sync manually since
 * client and server are separate TypeScript projects / build targets). */

export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
export type AgentName = 'TraceCode' | 'TraceProbe' | 'TraceLogic';
export type FindingStatus = 'OPEN' | 'VERIFIED_FIXED' | 'FAILED_RETEST';
export type AssessmentStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED';
export type ModuleName = 'TraceCode' | 'TraceProbe' | 'TraceLogic';

export interface AssessmentConfig {
  id: string;
  targetRepo: string;
  targetUrl: string;
  userAToken: string;
  userBToken: string;
  selectedModules: ModuleName[];
  createdAt: string;
}

export interface Finding {
  id: string;
  assessmentId: string;
  title: string;
  severity: Severity;
  category: string;
  endpoint: string;
  method: string;
  agent: AgentName;
  description: string;
  httpRequest: string;
  httpResponse: string;
  proof: string;
  status: FindingStatus;
  discoveredAt: string;
}

export interface RetestResult {
  findingId: string;
  isResolved: boolean;
  newHttpResponse: string;
  aiExplanation: string;
  timestamp: string;
}

export interface ProgressEvent {
  type: 'agent_status' | 'finding' | 'log' | 'assessment_complete' | 'error';
  agent?: AgentName | 'orchestrator';
  message?: string;
  progress?: number;
  finding?: Finding;
  assessmentId: string;
  timestamp: string;
}

export interface Assessment {
  config: AssessmentConfig;
  status: AssessmentStatus;
  findings: Finding[];
  retestLogs: RetestResult[];
  startedAt?: string;
  completedAt?: string;
}

export interface AgentStatus {
  name: AgentName;
  state: 'IDLE' | 'ACTIVE' | 'DONE' | 'ERROR';
  message: string;
  progress: number;
}
