import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Bell,
  FileText,
  LayoutDashboard,
  ListChecks,
  Play,
  Settings,
  Shield,
  ShieldCheck,
} from 'lucide-react';
import AgentCard from './AgentCard';
import FindingList from './FindingList';
import InspectorPanel from './InspectorPanel';
import RetestStudio from './RetestStudio';
import { createAssessment, runRetest, subscribeToAssessment } from '../services/api';
import { AgentName, AgentStatus, Finding, ModuleName, ProgressEvent, RetestResult } from '../types';

const AGENT_ORDER: AgentName[] = ['TraceCode', 'TraceProbe', 'TraceLogic'];

function initialAgentStatuses(): Record<AgentName, AgentStatus> {
  return {
    TraceCode: { name: 'TraceCode', state: 'IDLE', message: 'Waiting to start...', progress: 0 },
    TraceProbe: { name: 'TraceProbe', state: 'IDLE', message: 'Waiting to start...', progress: 0 },
    TraceLogic: { name: 'TraceLogic', state: 'IDLE', message: 'Waiting to start...', progress: 0 },
  };
}

type RetestPhase = 'running' | 'done' | 'error';

export default function Dashboard() {
  const [targetRepo, setTargetRepo] = useState('https://github.com/example-org/secure-api');
  const [targetUrl, setTargetUrl] = useState('https://api.example.com');
  const [userAToken, setUserAToken] = useState('');
  const [userBToken, setUserBToken] = useState('');

  const [assessmentId, setAssessmentId] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [elapsedSec, setElapsedSec] = useState(0);
  const [agentStatuses, setAgentStatuses] = useState<Record<AgentName, AgentStatus>>(initialAgentStatuses());
  const [findings, setFindings] = useState<Finding[]>([]);
  const [selectedFinding, setSelectedFinding] = useState<Finding | null>(null);
  const [setupError, setSetupError] = useState<string | null>(null);
  const [connectionNotice, setConnectionNotice] = useState<string | null>(null);

  const [retestPhase, setRetestPhase] = useState<RetestPhase | null>(null);
  const [retestResult, setRetestResult] = useState<RetestResult | null>(null);
  const [retestError, setRetestError] = useState<string | null>(null);
  const [retestFinding, setRetestFinding] = useState<Finding | null>(null);

  const unsubscribeRef = useRef<(() => void) | null>(null);
  const timerRef = useRef<number | null>(null);

  const totalFindings = findings.length;
  const findingsByAgent = (agent: AgentName) => findings.filter((f) => f.agent === agent).length;
  const activeAgents = AGENT_ORDER.filter((a) => agentStatuses[a].state === 'ACTIVE').length;

  const handleEvent = useCallback((event: ProgressEvent) => {
    if (event.type === 'agent_status' && event.agent && event.agent !== 'orchestrator') {
      const agent = event.agent as AgentName;
      setAgentStatuses((prev) => ({
        ...prev,
        [agent]: {
          name: agent,
          state: event.progress === 100 ? 'DONE' : 'ACTIVE',
          message: event.message ?? prev[agent].message,
          progress: event.progress ?? prev[agent].progress,
        },
      }));
    }
    if (event.type === 'finding' && event.finding) {
      setFindings((prev) => (prev.some((f) => f.id === event.finding!.id) ? prev : [...prev, event.finding!]));
    }
    if (event.type === 'error' && event.agent && event.agent !== 'orchestrator') {
      const agent = event.agent as AgentName;
      setAgentStatuses((prev) => ({ ...prev, [agent]: { ...prev[agent], state: 'ERROR', message: event.message ?? 'Agent error' } }));
    }
    if (event.type === 'assessment_complete') {
      setScanning(false);
      if (timerRef.current) window.clearInterval(timerRef.current);
    }
  }, []);

  const startScan = async () => {
    setSetupError(null);
    if (!targetUrl.trim() && !targetRepo.trim()) {
      setSetupError('Provide at least a target API Base URL or a repository.');
      return;
    }

    unsubscribeRef.current?.();
    setFindings([]);
    setSelectedFinding(null);
    setAgentStatuses(initialAgentStatuses());
    setElapsedSec(0);
    setConnectionNotice(null);

    const selectedModules: ModuleName[] = ['TraceCode', 'TraceProbe', 'TraceLogic'];
    const result = await createAssessment({ targetRepo, targetUrl, userAToken, userBToken, selectedModules });

    if (!result.ok || !result.data) {
      setSetupError(result.error ?? 'Failed to start assessment.');
      return;
    }

    setAssessmentId(result.data.id);
    setScanning(true);

    if (timerRef.current) window.clearInterval(timerRef.current);
    timerRef.current = window.setInterval(() => setElapsedSec((s) => s + 1), 1000);

    unsubscribeRef.current = subscribeToAssessment(
      result.data.id,
      handleEvent,
      (message) => setConnectionNotice(message)
    );
  };

  useEffect(() => {
    return () => {
      unsubscribeRef.current?.();
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, []);

  const handleRetest = async (finding: Finding) => {
    if (!assessmentId) return;
    setRetestFinding(finding);
    setRetestPhase('running');
    setRetestResult(null);
    setRetestError(null);

    const result = await runRetest(assessmentId, finding.id);
    if (!result.ok || !result.data) {
      setRetestPhase('error');
      setRetestError(result.error ?? 'Retest failed.');
      return;
    }

    setRetestResult(result.data);
    setRetestPhase('done');
    setFindings((prev) =>
      prev.map((f) => (f.id === finding.id ? { ...f, status: result.data!.isResolved ? 'VERIFIED_FIXED' : 'FAILED_RETEST' } : f))
    );
    setSelectedFinding((prev) =>
      prev && prev.id === finding.id ? { ...prev, status: result.data!.isResolved ? 'VERIFIED_FIXED' : 'FAILED_RETEST' } : prev
    );
  };

  return (
    <div className="h-screen flex bg-trace-bg text-slate-200">
      <Sidebar />

      <div className="flex-1 flex flex-col min-w-0">
        <TopBar activeAgents={activeAgents} scanning={scanning} />

        <ScanSetupBar
          targetRepo={targetRepo}
          targetUrl={targetUrl}
          userAToken={userAToken}
          userBToken={userBToken}
          onTargetRepo={setTargetRepo}
          onTargetUrl={setTargetUrl}
          onUserAToken={setUserAToken}
          onUserBToken={setUserBToken}
          onRun={startScan}
          scanning={scanning}
          elapsedSec={elapsedSec}
        />

        {setupError && (
          <div className="mx-6 mt-3 rounded-lg border border-trace-critical/30 bg-trace-critical/5 text-trace-critical text-xs px-3 py-2">
            {setupError}
          </div>
        )}
        {connectionNotice && (
          <div className="mx-6 mt-3 rounded-lg border border-trace-medium/30 bg-trace-medium/5 text-trace-medium text-xs px-3 py-2">
            {connectionNotice}
          </div>
        )}

        <div className="flex gap-3 px-6 py-4">
          {AGENT_ORDER.map((agent) => (
            <AgentCard key={agent} status={agentStatuses[agent]} findingsCount={findingsByAgent(agent)} />
          ))}
        </div>

        <div className="flex-1 flex min-h-0 px-6 pb-6 gap-4">
          <div className="w-[420px] shrink-0 rounded-xl border border-trace-border bg-trace-panel overflow-hidden flex flex-col">
            <FindingList findings={findings} selectedId={selectedFinding?.id ?? null} onSelect={setSelectedFinding} />
          </div>
          <div className="flex-1 rounded-xl border border-trace-border bg-trace-panel overflow-hidden flex flex-col">
            <InspectorPanel
              finding={selectedFinding}
              onClose={() => setSelectedFinding(null)}
              onRetest={handleRetest}
              retestInFlight={retestPhase === 'running' && retestFinding?.id === selectedFinding?.id}
            />
          </div>
        </div>
      </div>

      {retestPhase && retestFinding && (
        <RetestStudio
          finding={retestFinding}
          phase={retestPhase}
          result={retestResult}
          errorMessage={retestError}
          onClose={() => setRetestPhase(null)}
        />
      )}
    </div>
  );
}

function Sidebar() {
  const items = [
    { icon: LayoutDashboard, label: 'Dashboard', active: true },
    { icon: ShieldCheck, label: 'Findings' },
    { icon: FileText, label: 'Reports' },
    { icon: Settings, label: 'Settings' },
  ];
  return (
    <aside className="w-56 shrink-0 border-r border-trace-border bg-trace-panel flex flex-col">
      <div className="flex items-center gap-2 px-5 py-5">
        <Shield className="text-trace-accent" size={22} />
        <span className="font-bold tracking-wide text-slate-100 text-lg">TRACE</span>
      </div>
      <nav className="flex-1 px-3 space-y-1">
        {items.map(({ icon: Icon, label, active }) => (
          <button
            key={label}
            className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
              active ? 'bg-trace-accent/10 text-trace-accent' : 'text-slate-400 hover:bg-trace-panelAlt hover:text-slate-200'
            }`}
          >
            <Icon size={16} />
            {label}
          </button>
        ))}
      </nav>
      <div className="px-5 py-4 text-[11px] text-slate-600 leading-relaxed border-t border-trace-border">
        Real Exploits.
        <br />
        Not Just Alerts.
      </div>
    </aside>
  );
}

function TopBar({ activeAgents, scanning }: { activeAgents: number; scanning: boolean }) {
  return (
    <header className="flex items-center justify-between px-6 py-3 border-b border-trace-border">
      <div className="flex items-center gap-6 text-sm text-slate-400">
        <span className="font-medium text-slate-200">Trace</span>
        <span>Analyze</span>
        <span>Confirm</span>
        <span>Secure</span>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className={`w-2 h-2 rounded-full ${scanning ? 'bg-trace-success animate-pulse' : 'bg-slate-600'}`} />
          System {scanning ? `Online · ${activeAgents}/3 agents active` : 'Online'}
        </div>
        <Bell size={16} className="text-slate-500" />
        <div className="flex items-center gap-2 text-sm text-slate-300">
          <div className="w-7 h-7 rounded-full bg-trace-accent/20 flex items-center justify-center text-xs font-semibold text-trace-accent">
            BM
          </div>
          Bless Maota
        </div>
      </div>
    </header>
  );
}

interface ScanSetupBarProps {
  targetRepo: string;
  targetUrl: string;
  userAToken: string;
  userBToken: string;
  onTargetRepo: (v: string) => void;
  onTargetUrl: (v: string) => void;
  onUserAToken: (v: string) => void;
  onUserBToken: (v: string) => void;
  onRun: () => void;
  scanning: boolean;
  elapsedSec: number;
}

function ScanSetupBar(props: ScanSetupBarProps) {
  const [showTokens, setShowTokens] = useState(false);
  const mins = String(Math.floor(props.elapsedSec / 60)).padStart(2, '0');
  const secs = String(props.elapsedSec % 60).padStart(2, '0');

  return (
    <div className="px-6 py-4 space-y-3">
      <div className="flex items-end gap-3">
        <Field label="Target Repository / API" value={props.targetRepo} onChange={props.onTargetRepo} placeholder="https://github.com/org/repo" icon="repo" />
        <Field label="API Base URL" value={props.targetUrl} onChange={props.onTargetUrl} placeholder="https://api.example.com" icon="link" />
        <button
          onClick={props.onRun}
          disabled={props.scanning}
          className="flex items-center gap-2 bg-gradient-to-r from-trace-accent to-trace-accent2 text-white font-medium text-sm px-5 py-2.5 rounded-lg disabled:opacity-60 disabled:cursor-not-allowed hover:opacity-90 transition-opacity whitespace-nowrap h-[42px]"
        >
          <Play size={15} fill="currentColor" />
          {props.scanning ? 'Scan in progress...' : 'Run TRACE Scan'}
        </button>
        {props.scanning && (
          <div className="text-xs text-slate-400 flex items-center gap-1 h-[42px] px-1 whitespace-nowrap">
            Elapsed: {mins}:{secs}
          </div>
        )}
      </div>

      <button
        onClick={() => setShowTokens((v) => !v)}
        className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-300"
      >
        <ListChecks size={13} />
        {showTokens ? 'Hide' : 'Set'} dual-user auth tokens for IDOR testing (optional, required for TraceLogic)
      </button>

      {showTokens && (
        <div className="flex gap-3">
          <Field label="User A Token" value={props.userAToken} onChange={props.onUserAToken} placeholder="Bearer token for User A" secret />
          <Field label="User B Token" value={props.userBToken} onChange={props.onUserBToken} placeholder="Bearer token for User B" secret />
        </div>
      )}

      <p className="text-[11px] text-slate-600">
        Only run assessments against targets you are authorized to test (staging environments, dedicated sandboxes, or
        deliberately vulnerable apps such as OWASP Juice Shop).
      </p>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  icon,
  secret,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  icon?: 'repo' | 'link';
  secret?: boolean;
}) {
  return (
    <label className="flex-1 min-w-0">
      <span className="block text-xs text-slate-500 mb-1">{label}</span>
      <input
        type={secret ? 'password' : 'text'}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-trace-panel border border-trace-border rounded-lg px-3 py-2 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-trace-accent font-mono"
      />
    </label>
  );
}
