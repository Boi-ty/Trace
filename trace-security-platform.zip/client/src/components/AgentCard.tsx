import { ShieldAlert, Radar, KeyRound, LucideIcon } from 'lucide-react';
import { AgentName } from '../types';
import { AgentStatus } from '../types';

interface AgentCardProps {
  status: AgentStatus;
  findingsCount: number;
}

const AGENT_META: Record<AgentName, { label: string; icon: LucideIcon; accent: string; glow: string }> = {
  TraceCode: { label: 'SAST', icon: ShieldAlert, accent: 'text-trace-success', glow: 'shadow-[0_0_20px_rgba(34,197,94,0.1)]' },
  TraceProbe: { label: 'DAST', icon: Radar, accent: 'text-trace-accent', glow: 'shadow-[0_0_20px_rgba(59,130,246,0.1)]' },
  TraceLogic: { label: 'Auth & Logic', icon: KeyRound, accent: 'text-trace-accent2', glow: 'shadow-[0_0_20px_rgba(139,92,246,0.1)]' },
};

const STATE_BADGE: Record<AgentStatus['state'], string> = {
  IDLE: 'bg-slate-700/40 text-slate-400 border-slate-600/40',
  ACTIVE: 'bg-trace-success/10 text-trace-success border-trace-success/30',
  DONE: 'bg-trace-accent/10 text-trace-accent border-trace-accent/30',
  ERROR: 'bg-trace-critical/10 text-trace-critical border-trace-critical/30',
};

export default function AgentCard({ status, findingsCount }: AgentCardProps) {
  const meta = AGENT_META[status.name];
  const Icon = meta.icon;
  const isActive = status.state === 'ACTIVE';

  return (
    <div className={`flex-1 min-w-[260px] rounded-xl border border-trace-border bg-trace-panel p-4 ${meta.glow}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className={`rounded-lg bg-trace-panelAlt p-2 ${meta.accent}`}>
            <Icon size={18} strokeWidth={2} className={isActive ? 'animate-pulse-glow' : ''} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-100">{status.name}</span>
              <span className="text-xs text-slate-500">({meta.label})</span>
            </div>
          </div>
        </div>
        <span className={`text-[11px] font-medium tracking-wide px-2 py-0.5 rounded-full border ${STATE_BADGE[status.state]}`}>
          {status.state}
        </span>
      </div>

      <p className="text-xs text-slate-400 mb-3 truncate" title={status.message}>
        {status.message || 'Waiting to start...'}
      </p>

      <div className="h-1.5 w-full rounded-full bg-trace-panelAlt overflow-hidden mb-2">
        <div
          className={`h-full rounded-full transition-all duration-500 ${
            status.state === 'ERROR' ? 'bg-trace-critical' : 'bg-gradient-to-r from-trace-accent to-trace-accent2'
          }`}
          style={{ width: `${Math.max(status.progress, status.state === 'DONE' ? 100 : 0)}%` }}
        />
      </div>

      <div className="flex items-center justify-between text-xs text-slate-500">
        <span>{status.progress}% complete</span>
        <span>
          {findingsCount} finding{findingsCount === 1 ? '' : 's'}
        </span>
      </div>
    </div>
  );
}
