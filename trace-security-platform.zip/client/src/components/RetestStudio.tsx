import { CheckCircle2, Loader2, ShieldX, X } from 'lucide-react';
import { Finding, RetestResult } from '../types';

interface RetestStudioProps {
  finding: Finding;
  phase: 'running' | 'done' | 'error';
  result: RetestResult | null;
  errorMessage: string | null;
  onClose: () => void;
}

export default function RetestStudio({ finding, phase, result, errorMessage, onClose }: RetestStudioProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-sm">
      <div className="h-full w-full max-w-xl bg-trace-panel border-l border-trace-border shadow-2xl flex flex-col animate-[slideIn_0.2s_ease-out]">
        <div className="flex items-center justify-between px-5 py-4 border-b border-trace-border">
          <div>
            <h2 className="font-semibold text-slate-100">Retest Studio</h2>
            <p className="text-xs text-slate-500 mt-0.5">{finding.title}</p>
          </div>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-300">
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto scrollbar-thin p-5 space-y-5">
          {phase === 'running' && (
            <div className="flex flex-col items-center justify-center py-16 gap-3 text-center">
              <Loader2 size={32} className="animate-spin text-trace-accent" />
              <p className="text-sm text-slate-300">Re-issuing the original request against the live target...</p>
              <p className="text-xs text-slate-500 font-mono">
                {finding.method} {finding.endpoint}
              </p>
            </div>
          )}

          {phase === 'error' && (
            <div className="rounded-lg border border-trace-critical/30 bg-trace-critical/5 p-4">
              <p className="text-sm text-trace-critical font-medium mb-1">Retest could not complete</p>
              <p className="text-xs text-slate-400">{errorMessage}</p>
            </div>
          )}

          {phase === 'done' && result && (
            <>
              <div
                className={`flex items-center gap-3 rounded-lg border p-4 ${
                  result.isResolved
                    ? 'border-trace-success/30 bg-trace-success/5'
                    : 'border-trace-critical/30 bg-trace-critical/5'
                }`}
              >
                {result.isResolved ? (
                  <CheckCircle2 size={24} className="text-trace-success shrink-0" />
                ) : (
                  <ShieldX size={24} className="text-trace-critical shrink-0" />
                )}
                <div>
                  <p className={`font-semibold ${result.isResolved ? 'text-trace-success' : 'text-trace-critical'}`}>
                    {result.isResolved ? 'VERIFIED FIXED' : 'STILL VULNERABLE'}
                  </p>
                  <p className="text-xs text-slate-400 mt-0.5">{new Date(result.timestamp).toLocaleString()}</p>
                </div>
              </div>

              <div>
                <p className="text-xs font-semibold text-slate-400 mb-2">AI Explanation</p>
                <p className="text-sm text-slate-300 leading-relaxed bg-trace-panelAlt rounded-lg p-3 border border-trace-border">
                  {result.aiExplanation}
                </p>
              </div>

              <div>
                <p className="text-xs font-semibold text-slate-400 mb-2">Response Diff</p>
                <div className="grid grid-cols-1 gap-3">
                  <DiffBlock label="Original (vulnerable) response" content={finding.httpResponse} tone="critical" />
                  <DiffBlock label="New response" content={result.newHttpResponse} tone={result.isResolved ? 'success' : 'critical'} />
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function DiffBlock({ label, content, tone }: { label: string; content: string; tone: 'success' | 'critical' }) {
  const border = tone === 'success' ? 'border-trace-success/30' : 'border-trace-critical/30';
  return (
    <div className={`rounded-lg border ${border} bg-trace-bg overflow-hidden`}>
      <p className="text-[11px] text-slate-500 px-3 pt-2">{label}</p>
      <pre className="text-xs font-mono text-slate-300 p-3 whitespace-pre-wrap break-all max-h-56 overflow-y-auto scrollbar-thin">
        {content}
      </pre>
    </div>
  );
}
