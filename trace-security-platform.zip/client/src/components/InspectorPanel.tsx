import { useState } from 'react';
import { ArrowLeft, Copy, Lightbulb, RefreshCw } from 'lucide-react';
import { Finding, Severity } from '../types';

interface InspectorPanelProps {
  finding: Finding | null;
  onClose: () => void;
  onRetest: (finding: Finding) => void;
  retestInFlight: boolean;
}

const SEVERITY_BADGE: Record<Severity, string> = {
  CRITICAL: 'bg-trace-critical/15 text-trace-critical border-trace-critical/30',
  HIGH: 'bg-trace-high/15 text-trace-high border-trace-high/30',
  MEDIUM: 'bg-trace-medium/15 text-trace-medium border-trace-medium/30',
  LOW: 'bg-trace-low/15 text-trace-low border-trace-low/30',
};

type Tab = 'reqres' | 'code' | 'explanation';

export default function InspectorPanel({ finding, onClose, onRetest, retestInFlight }: InspectorPanelProps) {
  const [tab, setTab] = useState<Tab>('reqres');
  const [copied, setCopied] = useState(false);

  if (!finding) {
    return (
      <div className="flex items-center justify-center h-full text-slate-500 text-sm">
        Select a finding to inspect its proof of exploitability.
      </div>
    );
  }

  const handleCopy = async () => {
    const text = `${finding.httpRequest}\n\n${finding.httpResponse}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // Clipboard API may be unavailable (insecure context); fail silently.
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-4 py-3 border-b border-trace-border">
        <div className="flex items-center gap-3">
          <button onClick={onClose} className="text-slate-500 hover:text-slate-300">
            <ArrowLeft size={18} />
          </button>
          <h2 className="font-semibold text-slate-100">{finding.title}</h2>
          <span className={`text-[11px] px-2 py-0.5 rounded border font-medium ${SEVERITY_BADGE[finding.severity]}`}>
            {finding.severity}
          </span>
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 border border-trace-border rounded-md px-2 py-1"
        >
          <Copy size={13} /> {copied ? 'Copied' : 'Copy All'}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin p-4 space-y-4">
        <p className="text-sm text-slate-300 leading-relaxed">{finding.description}</p>

        <div className="grid grid-cols-3 gap-3">
          <InfoTile label="Affected Endpoint" value={`${finding.method} ${finding.endpoint}`} mono />
          <InfoTile label="Category" value={finding.category} accent="text-trace-critical" />
          <InfoTile label="Agent Validation" value={finding.agent} accent="text-trace-accent2" />
        </div>

        <div className="rounded-lg border border-trace-border overflow-hidden">
          <div className="flex items-center gap-1 border-b border-trace-border bg-trace-panelAlt px-2">
            <TabButton active={tab === 'reqres'} onClick={() => setTab('reqres')} label="Request / Response" />
            <TabButton active={tab === 'code'} onClick={() => setTab('code')} label="Code Context" />
            <TabButton active={tab === 'explanation'} onClick={() => setTab('explanation')} label="Explanation" />
          </div>

          {tab === 'reqres' && (
            <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-trace-border">
              <CodeBlock title="HTTP Request" content={finding.httpRequest} />
              <CodeBlock title="HTTP Response" content={finding.httpResponse} />
            </div>
          )}
          {tab === 'code' && (
            <div className="p-4 text-xs font-mono text-slate-400 bg-trace-bg whitespace-pre-wrap">
              {finding.agent === 'TraceCode'
                ? finding.proof
                : 'Code context is only available for findings produced by the TraceCode (SAST) agent.'}
            </div>
          )}
          {tab === 'explanation' && (
            <div className="p-4 text-sm text-slate-300 leading-relaxed">{finding.description}</div>
          )}
        </div>

        <div className="rounded-lg border border-trace-accent2/30 bg-trace-accent2/5 p-3 flex gap-2">
          <Lightbulb size={16} className="text-trace-accent2 shrink-0 mt-0.5" />
          <div>
            <p className="text-xs font-semibold text-trace-accent2 mb-1">Proof of Exploitability</p>
            <p className="text-xs text-slate-300 leading-relaxed">{finding.proof}</p>
          </div>
        </div>
      </div>

      <div className="border-t border-trace-border p-3 flex items-center justify-between">
        <StatusPill status={finding.status} />
        <button
          onClick={() => onRetest(finding)}
          disabled={retestInFlight}
          className="flex items-center gap-2 bg-gradient-to-r from-trace-accent to-trace-accent2 text-white text-sm font-medium px-4 py-2 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-90 transition-opacity"
        >
          <RefreshCw size={14} className={retestInFlight ? 'animate-spin' : ''} />
          {retestInFlight ? 'Retesting...' : 'Run Retest'}
        </button>
      </div>
    </div>
  );
}

function InfoTile({ label, value, mono, accent }: { label: string; value: string; mono?: boolean; accent?: string }) {
  return (
    <div className="rounded-lg border border-trace-border bg-trace-panelAlt p-3">
      <p className="text-[11px] text-slate-500 mb-1">{label}</p>
      <p className={`text-sm font-medium ${mono ? 'font-mono' : ''} ${accent ?? 'text-slate-200'} truncate`}>{value}</p>
    </div>
  );
}

function TabButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`text-xs px-3 py-2 border-b-2 transition-colors ${
        active ? 'border-trace-accent text-slate-100' : 'border-transparent text-slate-500 hover:text-slate-300'
      }`}
    >
      {label}
    </button>
  );
}

function CodeBlock({ title, content }: { title: string; content: string }) {
  return (
    <div className="bg-trace-bg">
      <p className="text-[11px] text-slate-500 px-3 pt-2">{title}</p>
      <pre className="text-xs font-mono text-slate-300 p-3 whitespace-pre-wrap break-all max-h-72 overflow-y-auto scrollbar-thin">
        {content}
      </pre>
    </div>
  );
}

function StatusPill({ status }: { status: Finding['status'] }) {
  if (status === 'VERIFIED_FIXED') {
    return <span className="text-xs font-medium text-trace-success">✓ VERIFIED FIXED</span>;
  }
  if (status === 'FAILED_RETEST') {
    return <span className="text-xs font-medium text-trace-critical">✗ STILL VULNERABLE</span>;
  }
  return <span className="text-xs font-medium text-slate-500">OPEN — not yet retested</span>;
}
