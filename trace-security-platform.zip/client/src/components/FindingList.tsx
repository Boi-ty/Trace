import { useMemo, useState } from 'react';
import { Finding, Severity } from '../types';

interface FindingListProps {
  findings: Finding[];
  selectedId: string | null;
  onSelect: (finding: Finding) => void;
}

const SEVERITY_ORDER: Severity[] = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];

const SEVERITY_STYLE: Record<Severity, { dot: string; badge: string; label: string }> = {
  CRITICAL: { dot: 'bg-trace-critical', badge: 'bg-trace-critical/15 text-trace-critical border-trace-critical/30', label: 'CRITICAL' },
  HIGH: { dot: 'bg-trace-high', badge: 'bg-trace-high/15 text-trace-high border-trace-high/30', label: 'HIGH' },
  MEDIUM: { dot: 'bg-trace-medium', badge: 'bg-trace-medium/15 text-trace-medium border-trace-medium/30', label: 'MEDIUM' },
  LOW: { dot: 'bg-trace-low', badge: 'bg-trace-low/15 text-trace-low border-trace-low/30', label: 'LOW / INFO' },
};

const STATUS_STYLE: Record<Finding['status'], string> = {
  OPEN: '',
  VERIFIED_FIXED: 'border-l-2 border-l-trace-success',
  FAILED_RETEST: 'border-l-2 border-l-trace-critical',
};

type Filter = 'ALL' | Severity;

export default function FindingList({ findings, selectedId, onSelect }: FindingListProps) {
  const [filter, setFilter] = useState<Filter>('ALL');

  const grouped = useMemo(() => {
    const filtered = filter === 'ALL' ? findings : findings.filter((f) => f.severity === filter);
    const groups = new Map<Severity, Finding[]>();
    for (const sev of SEVERITY_ORDER) groups.set(sev, []);
    for (const f of filtered) groups.get(f.severity)?.push(f);
    return groups;
  }, [findings, filter]);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-4 py-3 border-b border-trace-border">
        <div className="flex items-center gap-2">
          <h2 className="font-semibold text-slate-100 text-sm">VERIFIED FINDINGS</h2>
          <span className="text-xs text-slate-500 bg-trace-panelAlt px-2 py-0.5 rounded-full">{findings.length} found</span>
        </div>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value as Filter)}
          className="bg-trace-panelAlt border border-trace-border text-xs rounded-md px-2 py-1 text-slate-300 focus:outline-none focus:ring-1 focus:ring-trace-accent"
        >
          <option value="ALL">All Severities</option>
          {SEVERITY_ORDER.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin">
        {findings.length === 0 && (
          <div className="p-6 text-center text-sm text-slate-500">No findings yet. Run a scan to populate this list.</div>
        )}
        {SEVERITY_ORDER.map((sev) => {
          const items = grouped.get(sev) ?? [];
          if (items.length === 0) return null;
          const style = SEVERITY_STYLE[sev];
          return (
            <div key={sev}>
              <div className="flex items-center gap-2 px-4 pt-3 pb-1">
                <span className={`w-2 h-2 rounded-full ${style.dot}`} />
                <span className="text-xs font-semibold tracking-wide text-slate-300">{style.label}</span>
                <span className="text-xs text-slate-500">{items.length}</span>
              </div>
              {items.map((finding) => (
                <button
                  key={finding.id}
                  onClick={() => onSelect(finding)}
                  className={`w-full text-left px-4 py-3 border-b border-trace-border/60 hover:bg-trace-panelAlt transition-colors ${
                    STATUS_STYLE[finding.status]
                  } ${selectedId === finding.id ? 'bg-trace-panelAlt ring-1 ring-inset ring-trace-accent/40' : ''}`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className={`w-2 h-2 rounded-full shrink-0 ${style.dot}`} />
                      <span className="text-sm font-medium text-slate-100 truncate">{finding.title}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded border shrink-0 ${style.badge}`}>{sev}</span>
                    </div>
                    <span className="text-[11px] text-slate-500 shrink-0">{relativeTime(finding.discoveredAt)}</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 truncate">{finding.description}</p>
                  <div className="flex items-center gap-1 mt-1 text-[11px] text-slate-500">
                    <span className="font-mono">{finding.method}</span>
                    <span className="font-mono truncate">{finding.endpoint}</span>
                    {finding.status === 'VERIFIED_FIXED' && <span className="text-trace-success ml-1">✓ Fixed</span>}
                    {finding.status === 'FAILED_RETEST' && <span className="text-trace-critical ml-1">✗ Still vulnerable</span>}
                  </div>
                </button>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function relativeTime(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}
