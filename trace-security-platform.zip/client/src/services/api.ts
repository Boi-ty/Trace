/**
 * Client API layer — all calls to the Trace orchestration server go through
 * here. Every function fails soft (returns a typed error) rather than
 * throwing, so a single flaky request can't take down the dashboard.
 */
import { Assessment, AssessmentConfig, ModuleName, ProgressEvent, RetestResult } from '../types';

const API_BASE = '/api';

export interface CreateAssessmentInput {
  targetRepo: string;
  targetUrl: string;
  userAToken: string;
  userBToken: string;
  selectedModules: ModuleName[];
}

export interface ApiResult<T> {
  ok: boolean;
  data?: T;
  error?: string;
}

export async function createAssessment(input: CreateAssessmentInput): Promise<ApiResult<{ id: string }>> {
  try {
    const res = await fetch(`${API_BASE}/assessments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    });
    const data = await res.json();
    if (!res.ok) return { ok: false, error: data?.error ?? `Request failed (${res.status})` };
    return { ok: true, data };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : 'Network error' };
  }
}

export async function fetchAssessment(id: string): Promise<ApiResult<Assessment>> {
  try {
    const res = await fetch(`${API_BASE}/assessments/${id}`);
    const data = await res.json();
    if (!res.ok) return { ok: false, error: data?.error ?? `Request failed (${res.status})` };
    return { ok: true, data };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : 'Network error' };
  }
}

export async function runRetest(assessmentId: string, findingId: string): Promise<ApiResult<RetestResult>> {
  try {
    const res = await fetch(`${API_BASE}/assessments/${assessmentId}/retest/${findingId}`, { method: 'POST' });
    const data = await res.json();
    if (!res.ok) return { ok: false, error: data?.error ?? `Request failed (${res.status})` };
    return { ok: true, data };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : 'Network error' };
  }
}

/**
 * Opens an SSE connection for live assessment progress. Returns a cleanup
 * function. `onEvent` is called for every progress event; `onError` is
 * called if the stream itself fails (e.g. server restarted).
 */
export function subscribeToAssessment(
  assessmentId: string,
  onEvent: (event: ProgressEvent) => void,
  onError?: (message: string) => void
): () => void {
  let source: EventSource | null = null;
  try {
    source = new EventSource(`${API_BASE}/assessments/${assessmentId}/stream`);
    source.onmessage = (ev) => {
      try {
        const parsed = JSON.parse(ev.data) as ProgressEvent;
        onEvent(parsed);
      } catch {
        // Ignore malformed events rather than crashing the UI.
      }
    };
    source.onerror = () => {
      onError?.('Live connection interrupted. Retrying...');
    };
  } catch (err) {
    onError?.(err instanceof Error ? err.message : 'Failed to open live stream');
  }

  return () => {
    source?.close();
  };
}
