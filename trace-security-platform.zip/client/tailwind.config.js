/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        trace: {
          bg: '#0a0e1a',
          panel: '#0f1420',
          panelAlt: '#121827',
          border: '#1e2638',
          accent: '#3b82f6',
          accent2: '#8b5cf6',
          critical: '#ef4444',
          high: '#f97316',
          medium: '#eab308',
          low: '#38bdf8',
          success: '#22c55e',
        },
      },
      fontFamily: {
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
        sans: ['Inter', 'ui-sans-serif', 'system-ui'],
      },
      boxShadow: {
        glow: '0 0 20px rgba(59, 130, 246, 0.15)',
      },
    },
  },
  plugins: [],
};
